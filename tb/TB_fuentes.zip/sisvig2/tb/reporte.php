<?php 
header("Content-type: application/vnd.ms-excel");
header("Content-Disposition: attachment;Filename=document_name.xls");

$db = mysql_connect('173.201.187.40:3306','excel_dev','a1b2c3d4') or die("Database error"); 
mysql_select_db('sisvigdb', $db); 

function getRows($query) {
 $r = mysql_query("set names 'utf8'"); 
 $r = mysql_query($query); 
 while($res = mysql_fetch_assoc($r)) { 
    return $res;
  }
 
}

 $result = mysql_query("set names 'utf8'"); 
 $result = mysql_query("select * from tb_form"); 




//$num_rows = mysql_num_rows($result);
// echo $num_rows;


// $numfields = mysql_num_fields($result);
// for ($i=0; $i < $numfields; $i++) // Header
// { echo mysql_field_name($result, $i).','; }
// echo "\n"; 
//  
   
?> 

 <?php
 function control() { ?> 
  <!-- Control --> 
  <td align=right>127</td>
  <td align=right>128</td>
  <td align=right>129</td>
  <td align=right>130</td>
  <td align=right>131</td>
  <td align=right>132</td>
  <td align=right>133</td>
  <td align=right>134</td>
   		<!-- resultados psd --> 
  <td align=right>135</td>
  <td align=right>136</td>
  <td align=right>137</td>
  <td align=right>138</td>
  <td align=right>139</td>
  <td align=right>140</td>
  <td align=right>141</td>
  		<!-- readcciones adversas --> 
  <td align=right>142</td>
  <td align=right>143</td>
  <td align=right>144</td>
  <td align=right>145</td>
  <td align=right>146</td>
  <td align=right>147</td>
	  <!-- situacion del paciente --> 
  <td align=right>148</td>
  <td align=right>149</td>
  <td align=right>150</td>
  <td align=right>151</td>
  <td align=right>152</td>
  <td align=right>153</td>
  <td align=right>154</td>
  <td align=right>155</td>
 
 <?php }?>
 
<html>

<head>
<meta http-equiv=Content-Type content="text/html; charset=macintosh">
<meta name=ProgId content=Excel.Sheet>
<meta name=Generator content="Microsoft Excel 14">
<link rel=File-List href="Table_files/filelist.xml">
<style>
<!--table
	{mso-displayed-decimal-separator:"\.";
	mso-displayed-thousand-separator:"\,";}
@page
	{margin:1.0in .75in 1.0in .75in;
	mso-header-margin:.5in;
	mso-footer-margin:.5in;}
.font8
	{color:black;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Calibri, sans-serif;
	mso-font-charset:0;}
.style0
	{mso-number-format:General;
	text-align:general;
	vertical-align:bottom;
	white-space:nowrap;
	mso-rotate:0;
	mso-background-source:auto;
	mso-pattern:auto;
	color:black;
	font-size:11.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Calibri, sans-serif;
	mso-font-charset:0;
	border:none;
	mso-protection:locked visible;
	mso-style-name:Normal;
	mso-style-id:0;}
td
	{mso-style-parent:style0;
	padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:black;
	font-size:11.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Calibri, sans-serif;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:general;
	vertical-align:bottom;
	border:none;
	mso-background-source:auto;
	mso-pattern:auto;
	mso-protection:locked visible;
	white-space:nowrap;
	mso-rotate:0;}
.xl65
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:.5pt solid windowtext;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl66
	{mso-style-parent:style0;
	color:red;
	font-size:10.0pt;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:.5pt solid windowtext;
	border-bottom:none;
	border-left:.5pt solid windowtext;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl67
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:.5pt solid windowtext;
	border-bottom:none;
	border-left:.5pt solid windowtext;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl68
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:.5pt solid windowtext;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl69
	{mso-style-parent:style0;
	color:red;
	font-size:10.0pt;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:.5pt solid windowtext;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl70
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:.5pt solid windowtext;
	border-bottom:none;
	border-left:.5pt solid windowtext;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl71
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:.5pt solid windowtext;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl72
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:.5pt solid windowtext;
	border-bottom:none;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl73
	{mso-style-parent:style0;
	color:red;
	font-size:10.0pt;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:.5pt solid windowtext;
	border-bottom:none;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl74
	{mso-style-parent:style0;
	color:red;
	font-size:10.0pt;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:.5pt solid windowtext;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl75
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:.5pt solid windowtext;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl76
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:.5pt solid windowtext;
	border-bottom:none;
	border-left:.5pt solid windowtext;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl77
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:.5pt solid windowtext;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl78
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl79
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:.5pt solid windowtext;
	border-bottom:none;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl80
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:none;
	border-bottom:none;
	border-left:.5pt solid windowtext;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl81
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl82
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:.5pt solid windowtext;
	border-bottom:none;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl83
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl84
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl85
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:.5pt solid windowtext;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl86
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl87
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl88
	{mso-style-parent:style0;
	color:red;
	font-size:10.0pt;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:.5pt solid windowtext;
	border-bottom:none;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl89
	{mso-style-parent:style0;
	color:red;
	font-size:10.0pt;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:.5pt solid windowtext;
	border-bottom:none;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl90
	{mso-style-parent:style0;
	color:red;
	font-size:10.0pt;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:.5pt solid windowtext;
	border-bottom:.5pt solid black;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl91
	{mso-style-parent:style0;
	color:black;
	font-size:8.0pt;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:.5pt solid windowtext;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl92
	{mso-style-parent:style0;
	color:black;
	font-size:8.0pt;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:.5pt solid black;
	border-bottom:none;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl93
	{mso-style-parent:style0;
	color:black;
	font-size:8.0pt;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:none;
	border-bottom:none;
	border-left:.5pt solid windowtext;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl94
	{mso-style-parent:style0;
	color:black;
	font-size:8.0pt;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:.5pt solid windowtext;
	border-bottom:none;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl95
	{mso-style-parent:style0;
	color:black;
	font-size:8.0pt;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:none;
	border-bottom:.5pt solid black;
	border-left:.5pt solid windowtext;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl96
	{mso-style-parent:style0;
	color:black;
	font-size:8.0pt;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:.5pt solid windowtext;
	border-bottom:.5pt solid black;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl97
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid black;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl98
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:.5pt solid windowtext;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl99
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:.5pt solid windowtext;
	border-bottom:none;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl100
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:none;
	border-bottom:none;
	border-left:.5pt solid windowtext;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl101
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl102
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:.5pt solid black;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl103
	{mso-style-parent:style0;
	color:black;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;}
.xl104
	{mso-style-parent:style0;
	color:black;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid black;
	background:#D8E4BC;
	mso-pattern:black none;}
.xl105
	{mso-style-parent:style0;
	color:black;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:.5pt solid black;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;}
.xl106
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:none;
	border-bottom:.5pt solid black;
	border-left:.5pt solid windowtext;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl107
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:.5pt solid windowtext;
	border-bottom:.5pt solid black;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl108
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:.5pt solid windowtext;
	background:#D8E4BC;
	mso-pattern:black none;}
.xl109
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;}
.xl110
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:.5pt solid windowtext;
	border-bottom:none;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;}
.xl111
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:none;
	border-bottom:none;
	border-left:.5pt solid windowtext;
	background:#D8E4BC;
	mso-pattern:black none;}
.xl112
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	background:#D8E4BC;
	mso-pattern:black none;}
.xl113
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:.5pt solid windowtext;
	border-bottom:none;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;}
.xl114
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	background:#D8E4BC;
	mso-pattern:black none;}
.xl115
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;}
.xl116
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:.5pt solid windowtext;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;}
.xl117
	{mso-style-parent:style0;
	color:red;
	font-size:10.0pt;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:.5pt solid windowtext;
	border-bottom:none;
	border-left:.5pt solid windowtext;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl118
	{mso-style-parent:style0;
	color:red;
	font-size:10.0pt;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:.5pt solid windowtext;
	border-bottom:.5pt solid black;
	border-left:.5pt solid windowtext;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl119
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:.5pt solid windowtext;
	border-bottom:none;
	border-left:.5pt solid windowtext;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl120
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:.5pt solid windowtext;
	border-bottom:.5pt solid black;
	border-left:.5pt solid windowtext;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl121
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl122
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	text-align:center;
	vertical-align:middle;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl123
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl124
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:.5pt solid black;
	border-bottom:none;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl125
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:.5pt solid black;
	border-bottom:none;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl126
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:.5pt solid black;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl127
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:.5pt solid black;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl128
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:none;
	border-bottom:none;
	border-left:.5pt solid black;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl129
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid black;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl130
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:.5pt solid windowtext;
	border-bottom:.5pt solid black;
	border-left:.5pt solid windowtext;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl131
	{mso-style-parent:style0;
	color:black;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;}
.xl132
	{mso-style-parent:style0;
	color:black;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:.5pt solid black;
	background:#D8E4BC;
	mso-pattern:black none;}
.xl133
	{mso-style-parent:style0;
	color:black;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:.5pt solid black;
	border-bottom:none;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;}
.xl134
	{mso-style-parent:style0;
	color:black;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:none;
	border-bottom:none;
	border-left:.5pt solid black;
	background:#D8E4BC;
	mso-pattern:black none;}
.xl135
	{mso-style-parent:style0;
	color:black;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	background:#D8E4BC;
	mso-pattern:black none;}
.xl136
	{mso-style-parent:style0;
	color:black;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:.5pt solid black;
	border-bottom:none;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;}
.xl137
	{mso-style-parent:style0;
	color:black;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid black;
	background:#D8E4BC;
	mso-pattern:black none;}
.xl138
	{mso-style-parent:style0;
	color:black;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;}
.xl139
	{mso-style-parent:style0;
	color:black;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:.5pt solid black;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;}
.xl140
	{mso-style-parent:style0;
	color:black;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:.5pt solid windowtext;
	border-bottom:none;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;}
.xl141
	{mso-style-parent:style0;
	color:black;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:.5pt solid windowtext;
	border-bottom:none;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;}
.xl142
	{mso-style-parent:style0;
	color:black;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:.5pt solid windowtext;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;}
.xl143
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:.5pt solid black;
	border-bottom:none;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl144
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:.5pt solid black;
	border-bottom:none;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl145
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:.5pt solid black;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl146
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:.5pt solid black;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl147
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:none;
	border-bottom:none;
	border-left:.5pt solid black;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl148
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid black;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl149
	{mso-style-parent:style0;
	color:windowtext;
	font-size:10.0pt;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:.5pt solid windowtext;
	border-bottom:none;
	border-left:.5pt solid windowtext;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl150
	{mso-style-parent:style0;
	color:windowtext;
	font-size:10.0pt;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:.5pt solid windowtext;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl151
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid black;
	border-right:.5pt solid windowtext;
	border-bottom:none;
	border-left:.5pt solid windowtext;
	background:#D8E4BC;
	mso-pattern:black none;
	white-space:normal;}
.xl152
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:.5pt solid windowtext;
	border-bottom:none;
	border-left:.5pt solid windowtext;
	background:#D8E4BC;
	mso-pattern:black none;}
.xl153
	{mso-style-parent:style0;
	color:black;
	font-size:10.0pt;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:.5pt solid windowtext;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	background:#D8E4BC;
	mso-pattern:black none;}
-->
</style>
</head>

<body link=blue vlink=purple>

<table border=0 cellpadding=0 cellspacing=0 width=11310 style='border-collapse:
 collapse;table-layout:fixed;width:11310pt'>
 <col width=65 span=174 style='mso-width-source:userset;mso-width-alt:2773;
 width:65pt'>
 <tr height=14 style='mso-height-source:userset;height:14.0pt'>
  <td rowspan=4 height=56 class=xl76 width=65 style='border-bottom:.5pt solid black;
  height:56.0pt;width:65pt'>ORDEN</td>
  <td colspan=5 rowspan=4 class=xl77 width=325 style='border-right:.5pt solid black;
  border-bottom:.5pt solid black;width:325pt'>UBICACI�N</td>
  <td class=xl65 width=65 style='width:65pt'>&nbsp;</td>
  <td colspan=24 class=xl87 width=1560 style='border-right:.5pt solid black;
  border-left:none;width:1560pt'>DATOS DE IDENTIFICACI�N</td>
  <td colspan=17 rowspan=4 class=xl77 width=1105 style='border-right:.5pt solid black;
  border-bottom:.5pt solid black;width:1105pt'>ANTECEDENTES DEL<span
  style="mso-spacerun:yes">&nbsp; </span>PACIENTE</td>
  <td colspan=20 class=xl87 width=1300 style='border-right:.5pt solid black;
  border-left:none;width:1300pt'>Metodo Diagn�stico<span
  style="mso-spacerun:yes">&nbsp;</span></td>
  <td rowspan=6 class=xl88 width=65 style='border-bottom:.5pt solid black;
  width:65pt'>CLASIFICACI�N</td>
  <td colspan=3 class=xl87 width=195 style='border-right:.5pt solid black;
  border-left:none;width:195pt'>Localizaci�n anat�mica</td>
  <td colspan=6 class=xl87 width=390 style='border-right:.5pt solid black;
  border-left:none;width:390pt'>Historia de tratamiento previo <font
  class="font8">(seleccione solo una opci�n)</font></td>
  <td colspan=2 class=xl91 width=130 style='border-right:.5pt solid black;
  border-left:none;width:130pt'>Condici�n de VIH</td>
  <td colspan=13 class=xl97 width=845 style='border-right:.5pt solid black;
  border-left:none;width:845pt'>Resistencia a los medicamentos <font
  class="font8">(al ingreso)</font></td>
  <td colspan=2 rowspan=4 class=xl98 width=130 style='border-right:.5pt solid black;
  border-bottom:.5pt solid black;width:130pt'>Referencia del paciente</td>
  <td colspan=8 class=xl87 width=520 style='border-right:.5pt solid black;
  border-left:none;width:520pt'>DATOS DEL TRATAMIENTO</td>
  <td colspan=24 class=xl104 width=1560 style='border-right:.5pt solid black;
  border-left:none;width:1560pt'>ACTIVIDADES COLABORATIVAS TB / VIH<span
  style="mso-spacerun:yes">&nbsp;</span></td>
  <td colspan=29 class=xl104 width=1885 style='border-right:.5pt solid black;
  border-left:none;width:1885pt'>CONTROL</td>
  <td colspan=10 class=xl97 width=650 style='border-right:.5pt solid black;
  border-left:none;width:650pt'>CONTACTOS</td>
  <td colspan=2 rowspan=4 class=xl77 width=130 style='border-right:.5pt solid black;
  border-bottom:.5pt solid black;width:130pt'>VISITAS DOMICILIARIAS</td>
  <td colspan=3 rowspan=4 class=xl108 width=195 style='border-right:.5pt solid black;
  border-bottom:.5pt solid black;width:195pt'>APOYOS</td>
  <td colspan=3 rowspan=4 class=xl77 width=195 style='border-right:.5pt solid black;
  border-bottom:.5pt solid black;width:195pt'>EGRESO</td>
 </tr>
 <tr height=14 style='mso-height-source:userset;height:14.0pt'>
  <td rowspan=5 height=98 class=xl117 width=65 style='border-bottom:.5pt solid black;
  height:98.0pt;border-top:none;width:65pt'>Tipo de documento*</td>
  <td rowspan=5 class=xl117 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>N�mero de documento*</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>Primer</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>Segundo</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>Primer</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>Segundo</td>
  <td rowspan=5 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Apellido de Casada</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>Fecha de</td>
  <td rowspan=5 class=xl117 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Tipo Edad*</td>
  <td rowspan=5 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Edad*</td>
  <td rowspan=5 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Sexo*</td>
  <td rowspan=5 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Embarazada</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>Semana
  Gestacional</td>
  <td class=xl66 width=65 style='border-left:none;width:65pt'>Grupo</td>
  <td rowspan=5 class=xl117 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Grupo Ind�gena</td>
  <td colspan=3 rowspan=3 class=xl98 width=195 style='border-right:.5pt solid black;
  border-bottom:.5pt solid black;width:195pt'>Ocupaci�n<span
  style="mso-spacerun:yes">&nbsp;</span></td>
  <td class=xl66 width=65 style='border-left:none;width:65pt'>Estado</td>
  <td rowspan=5 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Escolaridad</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>Direcci�n</td>
  <td rowspan=5 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Tel�fono*</td>
  <td colspan=3 rowspan=3 class=xl98 width=195 style='border-right:.5pt solid black;
  border-bottom:.5pt solid black;width:195pt'>Acudiente</td>
  <td colspan=9 rowspan=3 class=xl77 width=585 style='border-right:.5pt solid black;
  border-bottom:.5pt solid black;width:585pt'>BACILOSCOPIA</td>
  <td colspan=2 rowspan=3 class=xl127 width=130 style='border-right:.5pt solid black;
  border-bottom:.5pt solid black;width:130pt'>CULTIVO</td>
  <td colspan=3 rowspan=3 class=xl127 width=195 style='border-right:.5pt solid black;
  border-bottom:.5pt solid black;width:195pt'>OTRO (WRD)</td>
  <td colspan=2 rowspan=3 class=xl127 width=130 style='border-right:.5pt solid black;
  border-bottom:.5pt solid black;width:130pt'>CL�NICO</td>
  <td colspan=2 rowspan=3 class=xl127 width=130 style='border-right:.5pt solid black;
  border-bottom:.5pt solid black;width:130pt'>R-X</td>
  <td colspan=2 rowspan=3 class=xl127 width=130 style='border-right:.5pt solid black;
  border-bottom:.5pt solid black;width:130pt'>HISTOPATOLOGIA</td>
  <td rowspan=5 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Pulmonar</td>
  <td colspan=2 rowspan=3 class=xl77 width=130 style='border-right:.5pt solid black;
  border-bottom:.5pt solid black;width:130pt'>Extrapulmonar</td>
  <td rowspan=5 class=xl76 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Nuevo</td>
  <td colspan=4 rowspan=3 class=xl77 width=260 style='border-right:.5pt solid black;
  border-bottom:.5pt solid black;width:260pt'>Antes tratado</td>
  <td class=xl70 width=65 style='border-left:none;width:65pt'>Pacientes con
  historia desconocida</td>
  <td colspan=2 class=xl93 width=130 style='border-right:.5pt solid black;
  border-left:none;width:130pt'>(al momento del diagn�stico de TB)</td>
  <td rowspan=5 class=xl76 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Ninguna</td>
  <td rowspan=5 class=xl76 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>MonoR</td>
  <td colspan=7 rowspan=3 class=xl77 width=455 style='border-right:.5pt solid black;
  border-bottom:.5pt solid black;width:455pt'>PoliR</td>
  <td rowspan=5 class=xl76 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>MDR</td>
  <td rowspan=5 class=xl76 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>XDR</td>
  <td rowspan=5 class=xl76 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>TB-RR</td>
  <td rowspan=5 class=xl76 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Desconocida</td>
  <td colspan=4 rowspan=3 class=xl77 width=260 style='border-right:.5pt solid black;
  border-bottom:.5pt solid black;width:260pt'>FASE 1</td>
  <td colspan=4 rowspan=3 class=xl127 width=260 style='border-right:.5pt solid black;
  border-bottom:.5pt solid black;width:260pt'>FASE 2</td>
  <td colspan=14 rowspan=3 class=xl132 style='border-right:.5pt solid black;
  border-bottom:.5pt solid black'>Paciente sin prueba de VIH previa</td>
  <td colspan=10 rowspan=3 class=xl132 style='border-right:.5pt solid black;
  border-bottom:.5pt solid black'>Paciente con prueba de VIH previa</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>Fecha Control</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>Peso (kg)</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>N�mero de</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>Fecha</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>Resultado</td>
  <td rowspan=5 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Clasificaci�n BK control</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>Fecha Cultivo</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>Resultado</td>
  <td colspan=7 rowspan=3 class=xl98 width=455 style='border-right:.5pt solid black;
  border-bottom:.5pt solid black;width:455pt'>Resultado PSD Control 1</td>
  <td colspan=6 rowspan=3 class=xl98 width=390 style='border-right:.5pt solid black;
  border-bottom:.5pt solid black;width:390pt'>REACCIONES ADVERSAS A
  MEDICAMENTOS</td>
  <td colspan=8 rowspan=3 class=xl146 width=520 style='border-right:.5pt solid black;
  border-bottom:.5pt solid black;width:520pt'>SITUACION ACTUAL DEL PACIENTE</td>
  <td colspan=5 rowspan=3 class=xl127 width=325 style='border-right:.5pt solid black;
  border-bottom:.5pt solid black;width:325pt'>MENORES DE 5 A�OS</td>
  <td colspan=5 rowspan=3 class=xl77 width=325 style='border-right:.5pt solid black;
  border-bottom:.5pt solid black;width:325pt'>5 Y M�S A�OS</td>
 </tr>
 <tr height=14 style='mso-height-source:userset;height:14.0pt'>
  <td height=14 class=xl67 width=65 style='height:14.0pt;border-left:none;
  width:65pt'>Nombre*</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>Nombre*</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>Apellido*</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>Apellido*</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>nacimiento*</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>al Diagn�stico</td>
  <td class=xl66 width=65 style='border-left:none;width:65pt'>Poblacional</td>
  <td class=xl66 width=65 style='border-left:none;width:65pt'>Civil</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>Domicilio*</td>
  <td class=xl70 width=65 style='border-left:none;width:65pt'>de tratamientos
  previos por TB</td>
  <td colspan=2 class=xl93 width=130 style='border-right:.5pt solid black;
  border-left:none;width:130pt'>&nbsp;</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>M�dico 1</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>Control 1</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>Dosis a la</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>BK control</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>BK control</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>Control 1</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>Cultivo</td>
 </tr>
 <tr height=14 style='mso-height-source:userset;height:14.0pt'>
  <td height=14 class=xl67 width=65 style='height:14.0pt;border-left:none;
  width:65pt'>&nbsp;</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td class=xl66 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td class=xl66 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td class=xl70 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td colspan=2 class=xl95 width=130 style='border-right:.5pt solid black;
  border-left:none;width:130pt'>&nbsp;</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>fecha del</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>Control 1</td>
 </tr>
 <tr height=28 style='mso-height-source:userset;height:28.0pt'>
  <td rowspan=2 height=56 class=xl119 width=65 style='border-bottom:.5pt solid black;
  height:56.0pt;border-top:none;width:65pt'>No.</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Regi�n*</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Provincia*</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Distrito*</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Corregimiento*</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Instalaci�n de Salud*</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td class=xl66 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Empleado</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Profesi�n</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Otros</td>
  <td class=xl66 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Nombre de Familiar de Referencia *</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Parentesco</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Tel�fono de Familiar</td>
  <td rowspan=2 class=xl117 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Diabetes</td>
  <td rowspan=2 class=xl149 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Otro evento inmunodepresor</td>
  <td rowspan=2 class=xl117 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Personas Privadas de Libertad</td>
  <td rowspan=2 class=xl117 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Fecha de privaci�n de libertad</td>
  <td rowspan=2 class=xl117 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Usuario de droga</td>
  <td rowspan=2 class=xl117 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Alcoholismo</td>
  <td rowspan=2 class=xl117 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Tabaquismo</td>
  <td rowspan=2 class=xl117 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Miner�a</td>
  <td rowspan=2 class=xl117 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Hacinamiento</td>
  <td rowspan=2 class=xl117 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Indigencia</td>
  <td rowspan=2 class=xl117 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Acceso a agua potable</td>
  <td rowspan=2 class=xl117 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Acceso a saneamiento b�sico</td>
  <td class=xl73 width=65 style='width:65pt'>Contacto de</td>
  <td class=xl73 width=65 style='width:65pt'>Cicatriz</td>
  <td class=xl72 width=65 style='width:65pt'>Peso al</td>
  <td class=xl72 width=65 style='width:65pt'>Talla al</td>
  <td class=xl72 width=65 style='width:65pt'>Grupo de</td>
  <td class=xl72 width=65 style='width:65pt'>Fecha</td>
  <td class=xl72 width=65 style='width:65pt'>Resultado</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Clasificaci�n BK1</td>
  <td class=xl72 width=65 style='width:65pt'>Fecha</td>
  <td class=xl72 width=65 style='width:65pt'>Resultado</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Clasificaci�n BK2</td>
  <td class=xl72 width=65 style='width:65pt'>Fecha</td>
  <td class=xl72 width=65 style='width:65pt'>Resultado</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Clasificaci�n BK3</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Resultado</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Fecha</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>M�todo</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Resultado</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Fecha</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Resultado</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Fecha</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Resultado</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Fecha</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Resultado</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Fecha</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Extra-pulmonar (EP)</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Lugar EP</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Reca�da</td>
  <td class=xl72 width=65 style='width:65pt'>Tto. Post</td>
  <td class=xl72 width=65 style='width:65pt'>Despu�s de p�rdida</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Otros</td>
  <td class=xl70 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td rowspan=2 class=xl151 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Resultado</td>
  <td rowspan=2 class=xl151 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Fecha</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>H</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>R</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Z</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>E</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>S</td>
  <td class=xl72 width=65 style='width:65pt'>Fluoroqui</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Inyectables de 2a l�nea</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Referido</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Instalaci�n de salud de referencia</td>
  <td class=xl72 width=65 style='width:65pt'>Fecha</td>
  <td class=xl72 width=65 style='width:65pt'>Medicamentos</td>
  <td class=xl72 width=65 style='width:65pt'>Fecha</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Administraci�n<span
  style="mso-spacerun:yes">&nbsp;</span></td>
  <td class=xl72 width=65 style='width:65pt'>Fecha</td>
  <td class=xl72 width=65 style='width:65pt'>Medicamentos</td>
  <td class=xl72 width=65 style='width:65pt'>Fecha</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Administraci�n<span
  style="mso-spacerun:yes">&nbsp;</span></td>
  <td class=xl72 width=65 style='width:65pt'>Se solicit� la</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Paciente acept�<span
  style="mso-spacerun:yes">&nbsp; </span>hacerse la prueba</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Prueba VIH realizada</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Fecha toma muestra</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Resultado Prueba VIH<span
  style="mso-spacerun:yes">&nbsp;</span></td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Asesor�a post prueba VIH</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Terapia cotrimoxazol</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Fecha inicio Terapia cotrimoxazol</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Referido a TARV</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Fecha Referencia a TARV</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Inici� TARV?</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Fecha inicio TARV</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Lugar de administraci�n de la TARV</td>
  <td class=xl72 width=65 style='width:65pt'>Esquema</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Fecha de Prueba</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Resultado de VIH previa</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Asesor�a post prueba VIH Previa</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Terapia cotrimoxazol</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Fecha inicio Terapia cotrimoxazol</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Actualmente en TARV</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Fecha inicio TARV</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Lugar de administraci�n de la TARV</td>
  <td class=xl72 width=65 style='width:65pt'>Esquema</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Antecedente Terapia Isoniacida</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>control 1</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td class=xl67 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>H</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>R</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Z</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>E</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>S</td>
  <td class=xl72 width=65 style='width:65pt'>Fluoroqui</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Inyectables de 2a l�nea</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Reacci�n Adversa a Medicamentos</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Fecha Reaccion Adversa</td>
  <td rowspan=2 class=xl152 style='border-bottom:.5pt solid black;border-top:
  none'>Manifestaci�n</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Clasificaci�n<span
  style="mso-spacerun:yes">&nbsp;</span></td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Conducta</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Hospitalizado (Si/no)</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Persona privada de Libertad</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Fecha de privaci�n de libertad</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Usuario de drogas</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Alcoholismo</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Tabaquismo</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Miner�a</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Hacinamiento</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Empleado</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Total de contactos identificados</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Total de contactos Sintom�ticos
  Respiratorios<span style="mso-spacerun:yes">&nbsp;</span></td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Total de contactos evaluados</td>
  <td class=xl72 width=65 style='width:65pt'>Total de contactos con</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Total de contactos con TB<span
  style="mso-spacerun:yes">&nbsp;</span></td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Total de contactos identificados</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Total de contactos Sintom�ticos
  Respiratorios<span style="mso-spacerun:yes">&nbsp;</span></td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Total de contactos evaluados</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Total de contactos con Quimioprofilaxis</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Total de contactos con TB<span
  style="mso-spacerun:yes">&nbsp;</span></td>
  <td rowspan=2 class=xl151 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Tipo de visita</td>
  <td rowspan=2 class=xl151 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Fecha de visita</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Social</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Nutricional</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Econ�mico</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Fecha Egreso</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Condici�n Egreso</td>
  <td rowspan=2 class=xl119 width=65 style='border-bottom:.5pt solid black;
  border-top:none;width:65pt'>Motivo de Exclusi�n</td>
 </tr>
 <tr height=28 style='mso-height-source:userset;height:28.0pt'>
  <td height=28 class=xl68 width=65 style='height:28.0pt;border-left:none;
  width:65pt'>&nbsp;</td>
  <td class=xl68 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td class=xl68 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td class=xl68 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td class=xl68 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td class=xl68 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td class=xl69 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td class=xl69 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td class=xl68 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td class=xl74 width=65 style='width:65pt'>Caso Positivo</td>
  <td class=xl74 width=65 style='width:65pt'>de BCG</td>
  <td class=xl75 width=65 style='width:65pt'>ingreso (kg)<span
  style="mso-spacerun:yes">&nbsp;</span></td>
  <td class=xl75 width=65 style='width:65pt'>ingreso (m)</td>
  <td class=xl75 width=65 style='width:65pt'>Riesgo MDR</td>
  <td class=xl75 width=65 style='width:65pt'>BK1</td>
  <td class=xl75 width=65 style='width:65pt'>BK1</td>
  <td class=xl75 width=65 style='width:65pt'>BK2</td>
  <td class=xl75 width=65 style='width:65pt'>BK2</td>
  <td class=xl75 width=65 style='width:65pt'>BK3</td>
  <td class=xl75 width=65 style='width:65pt'>BK3</td>
  <td class=xl75 width=65 style='width:65pt'>fracaso</td>
  <td class=xl75 width=65 style='width:65pt'>en el seguimiento</td>
  <td class=xl71 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td class=xl75 width=65 style='width:65pt'>nolonas</td>
  <td class=xl75 width=65 style='width:65pt'>Inicio</td>
  <td class=xl75 width=65 style='width:65pt'>Indicados</td>
  <td class=xl75 width=65 style='width:65pt'>Fin</td>
  <td class=xl75 width=65 style='width:65pt'>Inicio</td>
  <td class=xl75 width=65 style='width:65pt'>Indicados</td>
  <td class=xl75 width=65 style='width:65pt'>Fin</td>
  <td class=xl75 width=65 style='width:65pt'>prueba VIH</td>
  <td class=xl75 width=65 style='width:65pt'>ARV</td>
  <td class=xl75 width=65 style='width:65pt'>ARV</td>
  <td class=xl68 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td class=xl68 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td class=xl68 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td class=xl68 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td class=xl68 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td class=xl68 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td class=xl68 width=65 style='border-left:none;width:65pt'>&nbsp;</td>
  <td class=xl75 width=65 style='width:65pt'>nolonas</td>
  <td class=xl75 width=65 style='width:65pt'>Quimioprofilaxis</td>
 </tr>
 
 <?php  while($row = mysql_fetch_assoc($result)) { ?>
 <tr height=14 style='height:14.0pt'>
  <td height=14 align=right style='height:14.0pt'><?=$row['id_tb']; ?></td>
  <!-- ubicacion -->
  <td align=right><?=$row['region']; ?></td>
  <td align=right><?= $row['provincia']; ?></td>
  <td align=right><?= $row['distrito']; ?></td>
  <td align=right><?= $row['id_corregimiento']; ?></td>
  <td align=right><?= $row['instalacion_salud']; ?></td>
  <!-- datos de identificacion --> 
  <td align=right><?=$row['tipo_identificacion']; ?></td>
  
  <?php $datos = getRows("select * from tbl_persona where numero_identificacion = '" . $row['numero_identificacion']. "'"); ?>
  
  <td align=right><?=$row['numero_identificacion']; ?></td>
  <td align=right><?=$datos['primer_nombre']; ?></td>
  <td align=right><?=$datos['segundo_nombre']; ?></td>
  <td align=right><?=$datos['primer_apellido']; ?></td>
  <td align=right><?=$datos['segundo_apellido']; ?></td>
  <td align=right><?=$datos['casada_apellido']; ?></td>
  <td align=right>&nbsp;<?php echo date("d/m/Y", strtotime($datos['fecha_nacimiento'])); ?></td>
  <td align=right><?=$datos['tipo_edad']; ?></td>
  <td align=right><?=$datos['edad']; ?></td>
  <td align=right><?=$datos['sexo']; ?></td>
  <td align=right><?php echo ($row['riesgo_embarazo'] == 1 ? "Si":"No"); ?></td>
  <td align=right><?=$row['riesgo_semana']; ?></td>
  <td align=right><?=$datos['id_gpopoblacional']; ?></td>
  <td align=right><?=$datos['id_etnia']; ?></td>
  <td align=right><?php echo $row['per_empleado']==1 ? "Si":"No"; ?></td>
  <td align=right><?=$row['id_profesion']; ?></td>
  <td align=right><?=$row['otrosprofesion']; ?></td>
  <td align=right><?=$datos['id_estado_civil']; ?></td>
  <td align=right><?=$datos['id_escolaridad']; ?></td>
  <td align=right><?=$row['per_direccion']; ?></td>
  <td align=right><?=$row['per_telefono']; ?></td>
  <td align=right><?=$row['per_nombre_referencia']; ?></td>
  <td align=right><?=$row['per_parentesco']; ?></td>
  <td align=right><?=$row['per_telefono_referencia']; ?></td>
  
  <!-- antecedentes del paciente --> 
  <td align=right><?php echo $row['ant_diabetes']==1 ? "Si": ($row['ant_diabetes'] ==0? "No":"NS"); ?></td>
  <td align=right>N/A</td>
  <td align=right><?php echo $row['ant_preso']==1 ? "Si": ($row['ant_preso'] ==0? "No":"NS"); ?></td>
  <td align=right>&nbsp;<?php echo date("d/m/Y", strtotime($row['ant_fecha_preso'])); ?></td>
  <td align=right><?php echo $row['ant_droga']==1 ? "Si": ($row['ant_droga'] ==0? "No":"NS"); ?></td>
  <td align=right><?php echo $row['ant_alcoholism']==1 ? "Si": ($row['ant_alcoholism'] ==0? "No":"NS"); ?></td>
  <td align=right><?php echo $row['ant_smoking']==1 ? "Si": ($row['ant_smoking'] ==0? "No":"NS"); ?></td>
  <td align=right><?php echo $row['ant_mining']==1 ? "Si": ($row['ant_mining'] ==0? "No":"NS"); ?></td>
  <td align=right><?php echo $row['ant_overcrowding']==1 ? "Si": ($row['ant_overcrowding'] ==0? "No":"NS"); ?></td>
  <td align=right><?php echo $row['ant_indigence']==1 ? "Si": ($row['ant_indigence'] ==0? "No":"NS"); ?></td>
  <td align=right><?php echo $row['ant_drinkable']==1 ? "Si": ($row['ant_drinkable'] ==0? "No":"NS"); ?></td>
  <td align=right><?php echo $row['ant_sanitation']==1 ? "Si": ($row['ant_sanitation'] ==0? "No":"NS"); ?></td>
  <td align=right><?php echo $row['ant_contactposi']==1 ? "Si": ($row['ant_contactposi'] ==0? "No":"NS"); ?></td>
  <td align=right><?php echo $row['ant_BCG']==1 ? "Si": ($row['ant_BCG'] ==0? "No":"NS"); ?></td>
  <td align=right><?=$row['ant_weight']; ?></td>
  <td align=right><?=$row['ant_height']; ?></td>
  <td align=right>N/A</td>
  
  <!-- metodo de diagnostico --> 
  <td align=right>&nbsp;<?php echo date("d/m/Y", strtotime($row['mat_diag_fecha_BK1'])); ?></td>
  <td align=right><?=$row['mat_diag_resultado_BK1']; ?></td>
  <td align=right><?=$row['id_clasificacion_BK1']; ?></td>
  <td align=right>&nbsp;<?php echo date("d/m/Y", strtotime($row['mat_diag_fecha_BK2'])); ?></td>
  <td align=right><?=$row['mat_diag_resultado_BK2']; ?></td>
  <td align=right><?=$row['id_clasificacion_BK2']; ?></td>
  <td align=right>&nbsp;<?php echo date("d/m/Y", strtotime($row['mat_diag_fecha_BK3'])); ?></td>
  <td align=right><?=$row['mat_diag_resultado_BK3']; ?></td>
  <td align=right><?=$row['id_clasificacion_BK3']; ?></td>
  <td align=right><?=$row['mat_diag_res_cultivo']; ?></td>
  <td align=right>&nbsp;<?php echo date("d/m/Y", strtotime($row['mat_diag_fecha_res_cultivo'])); ?></td>
  <td align=right><?=$row['mat_diag_metodo_WRD']; ?></td>
  <td align=right><?=$row['mat_diag_res_metodo_WRD']; ?></td>
  <td align=right>&nbsp;<?php echo date("d/m/Y", strtotime($row['mat_diag_fecha_res_WRD'])); ?></td>
  <td align=right><?=$row['mat_diag_res_clinico']; ?></td>
  <td align=right>&nbsp;<?=$row['mat_diag_fecha_clinico']; ?></td>
  <td align=right><?=$row['mat_diag_res_R_X']; ?></td>
  <td align=right>&nbsp;<?=$row['mat_diag_fecha_R_X']; ?></td>
  <td align=right><?=$row['mat_diag_res_histopa']; ?></td>
  <td align=right>&nbsp;<?=$row['mat_diag_fecha_histopa']; ?></td>
  
  <!-- Clasificacion --> 
  <td align=right><?=$row['clasificacion_tb']; ?></td>
  
  <!-- localizacion anatomica --> 
  <td align=right><?=$row['clas_pulmonar_EP']; ?></td>
  <td align=right><?=$row['clas_lugar_EP']; ?></td>
  <td align=right><?=$row['clas_trat_previo']; ?></td>
  
  <!-- historia tratamiento --> 
  <td align=right>N/A</td>
  <td align=right><?=$row['clas_recaida']; ?></td>
  <td align=right><?=$row['clas_postfracaso']; ?></td>
  <td align=right><?=$row['clas_perdsegui']; ?></td>
  <td align=right><?=$row['clas_otros_antestratado']; ?></td>
  <td align=right>&nbsp;</td>
  
  <!-- condicion VIH --> 
  <td align=right><?=$row['clas_diag_VIH']; ?></td>
  <td align=right>&nbsp;<?=$row['clas_fecha_diag_VIH']; ?></td>
  
  <!-- resistencia a los medicamentos  --> 
  <td align=right><?=$row['clas_met_diag']; ?></td>
  <td align=right><?=$row['clas_esp_MonoR']; ?></td>
  <td align=right><?=$row['clas_PoliR_H']; ?></td>
  <td align=right><?=$row['clas_PoliR_R']; ?></td>
  <td align=right><?=$row['clas_PoliR_Z']; ?></td>
  <td align=right><?=$row['clas_PoliR_E']; ?></td>
  <td align=right><?=$row['clas_PoliR_S']; ?></td>
  <td align=right><?=$row['clas_PoliR_fluoroquinolonas']; ?></td>
  <td align=right><?=$row['id_inyect_2linea']; ?></td>
  <td align=right><?=$row['mat_diag_MDR']; ?></td>
  <td align=right><?=$row['mat_diag_XDR']; ?></td>
  <td align=right><?=$row['mat_diag_TB-RR']; ?></td>
  <td align=right><?=$row['mat_diag_desconocida']; ?></td>
  
  <!-- referencia del paciente --> 
  <td align=right><?=$row['trat_referido']; ?></td>
  <td align=right><?=$row['trat_inst_salud_ref']; ?></td>
  
  <!-- fase 1 --> 
  <td align=right>&nbsp;<?=$row['trat_fecha_inicio_tratF1']; ?></td>
  <td align=right><?=$row['trat_med_S_F1']; ?></td>
  <td align=right>&nbsp;<?=$row['trat_fecha_fin_tratF1']; ?></td>
  <td align=right><?=$row['id_adm_tratamiento_F1']; ?></td>
  
  <!-- fase 2 --> 
  <td align=right>&nbsp;<?=$row['trat_fecha_inicio_tratF2']; ?></td>
  <td align=right><?=$row['trat_med_otros_F2']; ?></td>
  <td align=right>&nbsp;<?=$row['trat_fecha_fin_tratF2']; ?></td>
  <td align=right><?=$row['id_adm_tratamiento_F2']; ?></td>
  
  <!-- actividades colaborativas --> 
  <td align=right><?php echo ($row['TB_VIH_solicitud_VIH'] == 1 ? "Si":"No"); ?></td>
  <td align=right><?php echo ($row['TB_VIH_acepto_VIH'] == 1 ? "Si":"No"); ?></td>
  <td align=right><?=$row['TB_VIH_realizada_VIH']; ?></td>
  <td align=right>&nbsp;<?=$row['TB_VIH_fecha_muestra_VIH']; ?></td>
  <td align=right><?=$row['TB_VIH_res_VIH']; ?></td>
  <td align=right><?=$row['TB_VIH_aseso_VIH']; ?></td>
  <td align=right><?=$row['TB_VIH_cotrimoxazol']; ?></td>
  <td align=right>&nbsp;<?=$row['TB_VIH_fecha_cotrimoxazol']; ?></td>
  <td align=right><?=$row['TB_VIH_ref_TARV']; ?></td>
  <td align=right>&nbsp;<?=$row['TB_VIH_fecha_ref_TARV']; ?></td>
  <td align=right><?php echo ($row['TB_VIH_inicio_TARV'] == 1 ? "Si":"No"); ?></td>
  <td align=right>&nbsp;<?=$row['TB_VIH_fecha_inicio_TARV']; ?></td>
  <td align=right><?=$row['TB_VIH_lug_adm_TARV']; ?></td>
  <td align=right><?=$row['TB_VIH_esq_ARV']; ?></td>
  <td align=right>&nbsp;<?=$row['TB_VIH_fecha_prueba_VIH']; ?></td>
  <td align=right><?=$row['TB_VIH_res_previa_VIH']; ?></td>
  <td align=right><?=$row['TB_VIH_isoniacida']; ?></td>
  <td align=right></td>
  <td align=right></td>
  <td align=right></td>
  <td align=right></td>
  <td align=right></td>
  <td align=right></td>
  <td align=right></td>
 

 <?php control();?>

  <!-- datos de identificacion --> 
  <td align=right>156</td>
  <td align=right>157</td>
  <td align=right>158</td>
  <td align=right>159</td>
  <td align=right>160</td>
  <td align=right>161</td>
  <td align=right>162</td>
  <td align=right>163</td>
  <td align=right>164</td>
  <td align=right>165</td>
  <td align=right>166</td>
  <td align=right>167</td>
  <td align=right>168</td>
  <td align=right>169</td>
  <td align=right>170</td>
  <td align=right>171</td>
  <td align=right>172</td>
  <td align=right>173</td>
 </tr>

<?php echo "\n" ?>
<?php } ?>



</table>

</body>

</html>
