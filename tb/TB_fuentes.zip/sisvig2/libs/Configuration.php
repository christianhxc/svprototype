<?php
class Configuration
{
    //const absolutePath = 'http://localhost/vigilab_hon/';
    //const absolutePath = 'http://192.168.1.24/vigilab_hon/';
//    const absolutePath = 'http://173.201.187.40/sisvig2/';
//    const absolutePath = 'http://186.74.193.11/sisvig2/';

    const DefaultTitleAdmin = 'SISVIG .::. Sistema de vigilancia en salud publica Panama';

    // BD LOCAL    
//    const DBHandler = 'mysql';
//    const DBuser = 'root';
//    const DBpass = 'mYnEwP';
//    const host = '10.0.0.92';
//    const DB = 'sisvigdb';
    
    // BD EN GODADDY
    const DBHandler = 'mysql';
    const DBuser = 'dtroncoso';
    const DBpass = 'dTBdFlu2010';
    const DB = 'sisvigdb';
    const host = 'localhost';
    
//    const DBHandler = 'mysql';
//    const DBuser = 'sisvig';
//    const DBpass = '123456';
//    const DB = 'sisvigdb';
//    const host = 'localhost';
    
    const templatesPath = 'D:/xampp/htdocs/sisvig2_173.201.187.40/trunk/templates/';
//    const templatesPath = '/var/www/html/sisvig2/templates/';

//    const bdEpiInfoPath = 'D:/xampp/htdocs/sisvig2_173.201.187.40/trunk/vih/archivos_bd/';
    const bdEpiInfoPath = '/var/www/html/sisvig2/vih/archivos_bd/';

    // No. de dias para cambiar una clave, si es 0 no solicita cambiar
    const expiracion = 0;

    // Id de las secciones de menú
    const idVigRutinaria = 70;
    const idVigMortalidad = 72;
    const idRumoresBrotes = 71;
    const idVigCentinela = 73;
    const idInvEspecial = 74;
    const idCatalogos = 4;

    // Cantidad de filas mostradas pagineo
    const paginado = 10;

//    const urlprefix ='http://localhost/sisvig2/';

//    const urlprefixViejo ='http://localhost/sisvig2/';
//    const javaAddress = 'C:/xampp/htdocs/sisvig2/bridge/java/Java.inc';
//    const reportAddress = 'http://localhost/sisvig2/';
//    const urlReport = "jdbc:mysql://localhost:3306/";
//    const dbReport = "sisvigdb?user=sisvig&password=123456";

//    const urlprefix = 'http://173.201.187.40/sisvig2/';    
    const urlprefixViejo ='http://173.201.187.40/pan/'; 
    const reportAddress = 'http://173.201.187.40/sisvig2/';    
    const urlReport = "jdbc:mysql://173.201.187.40:3306/";
    const dbReport = "sisvigdb?user=dtroncoso&password=dTBdFlu2010";
    const javaAddress = '/var/www/html/pan/bridge/java/Java.inc';

    public static function getAbsolutePath() {
        $pageURL = 'http';
        if ($_SERVER["HTTPS"] == "on") {
            $pageURL .= "s";
        }
        $pageURL .= "://";
        if ($_SERVER["SERVER_PORT"] != "80") {
            $pageURL .= $_SERVER["SERVER_NAME"] . ":" . $_SERVER["SERVER_PORT"];
        } else {
            $pageURL .= $_SERVER["SERVER_NAME"];
        }
        return $pageURL . "/sisvig2_173.201.187.40/trunk/";
    }
    
    public static function getUrlprefix() {
        $pageURL = 'http';
        if ($_SERVER["HTTPS"] == "on") {
            $pageURL .= "s";
        }
        $pageURL .= "://";
        if ($_SERVER["SERVER_PORT"] != "80") {
            $pageURL .= $_SERVER["SERVER_NAME"] . ":" . $_SERVER["SERVER_PORT"];
        } else {
            $pageURL .= $_SERVER["SERVER_NAME"];
        }
        return $pageURL . "/sisvig2_173.201.187.40/trunk/";
    }
}
?>
