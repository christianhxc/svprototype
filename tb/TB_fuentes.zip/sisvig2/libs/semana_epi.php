<?php

    if (isset ($_POST["time"])){
        $time = $_POST["time"];
        $data = array();
        $unDia = 86400;
        $varlist = strtotime($time);
        $anioActual = strftime("%Y", $varlist);

        $first_day = strtotime("01/01/".$anioActual);
        $wkday = strftime("%w", $first_day);
        $fwb = ($wkday<=3) ? ($first_day-($wkday*$unDia)) : ($first_day+(7*$unDia)-($wkday*$unDia));
        if ($varlist < $fwb){
            $first_day = strtotime("01/01/".($anioActual-1));
            $wkday = strftime("%w", $first_day);
            $fwb = ($wkday<=3) ? $first_day-($wkday*$unDia) : $first_day+(7*$unDia)-($wkday*$unDia);
        }

        $last_day = strtotime("12/31/".$anioActual);
        $wkday = strftime("%w", $last_day);
        $ewb = ($wkday<3) ? ($last_day-($wkday*$unDia))-(1*$unDia) : $last_day+(6*$unDia)-($wkday*$unDia);
        if ($varlist > $ewb)
            $fwb = $ewb+(1*$unDia);

        $semanaEpi = floor((($varlist-$fwb)/(7*$unDia))+1);
        $anioEpi = strftime("%Y", $fwb+(180*$unDia));
        
        $data["semana"] = $semanaEpi;
        $data["anio"] = $anioEpi;
        echo $semanaEpi."###".$anioEpi;
        //return $data;
    }
    
?>
